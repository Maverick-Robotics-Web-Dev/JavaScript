# Glass Card

A Pen created on CodePen.io. Original URL: [https://codepen.io/marcell0lopes/pen/YzLKxpR](https://codepen.io/marcell0lopes/pen/YzLKxpR).

Glass Card component