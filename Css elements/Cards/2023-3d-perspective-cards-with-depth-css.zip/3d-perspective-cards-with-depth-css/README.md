# 3D Perspective cards with depth [CSS]

A Pen created on CodePen.io. Original URL: [https://codepen.io/designfenix/pen/RwKPapa](https://codepen.io/designfenix/pen/RwKPapa).

I was looking forward to making an in-depth card example in CSS. I hope it helps someone! Greetings.