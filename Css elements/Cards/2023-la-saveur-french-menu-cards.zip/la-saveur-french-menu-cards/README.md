# La Saveur : French Menu Cards

A Pen created on CodePen.io. Original URL: [https://codepen.io/aryancodeworm/pen/mdMjbbp](https://codepen.io/aryancodeworm/pen/mdMjbbp).

Pure CSS based cards built heavily using `flexbox`. 
Images from [Unsplash](http://www.unsplash.com).
***
*From CPC November 2021*