# Marvel Corner Box Art

A Pen created on CodePen.io. Original URL: [https://codepen.io/aryancodeworm/pen/vYJzMgB](https://codepen.io/aryancodeworm/pen/vYJzMgB).

